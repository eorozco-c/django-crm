/*!
 Bootstrap integration for DataTables' SearchPanes
 ©2016 SpryMedia Ltd - datatables.net/license
*/
(function(c){"function"===typeof define&&define.amd?define(["jquery","datatables.net-zf","datatables.net-searchpanes"],function(a){return c(a,window,document)}):"object"===typeof exports?module.exports=function(a,b){a||(a=window);b&&b.fn.dataTable||(b=require("datatables.net-zf")(a,b).$);b.fn.dataTable.SearchPanes||require("datatables.net-searchpanes")(a,b);return c(b,a,a.document)}:c(jQuery,window,document)})(function(c,a,b){a=c.fn.dataTable;c.extend(!0,a.SearchPane.classes,{buttonGroup:"secondary button-group",
disabledButton:"disabled",narrow:"dtsp-narrow",narrowButton:"dtsp-narrowButton",narrowSearch:"dtsp-narrowSearch",paneButton:"secondary button",pill:"badge secondary",search:"search",searchLabelCont:"searchCont",show:"col",table:"unstriped"});c.extend(!0,a.SearchPanes.classes,{clearAll:"dtsp-clearAll button secondary",collapseAll:"dtsp-collapseAll button secondary",disabledButton:"disabled",panes:"panes dtsp-panesContainer",showAll:"dtsp-showAll button secondary",title:"dtsp-title"});return a.searchPanes});
